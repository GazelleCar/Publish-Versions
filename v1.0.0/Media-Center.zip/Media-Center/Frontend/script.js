// Apps

var splideApps = new Splide('#splideApps', {
  arrows: false,
  type: 'loop',
  perPage: 1,
  pagination: true,
});

splideApps.mount();


// End Apps


//  Car-Simulator
const imageContainer = document.getElementById('imageContainer');
let startX = 0;
let currentIndex = 0;
let oldTranslateX = 0;
//if isCarExistInMainBox is true , it's mean main image box have car image
let i = 0, isCarExistInMainBox = true,
  minimalImageBox = document.getElementById('minimalImageBox'),
  mainImageBox = document.getElementById('mainImageBox');

imageContainer.addEventListener('touchstart', (e) => {
  startX = e.touches[0].clientX;
});

imageContainer.addEventListener('touchmove', (e) => {
  const deltaX = e.touches[0].clientX - startX;
  const imagesCount = 30;
  const imageWidth = imageContainer.offsetWidth;

  if (Math.abs(deltaX) > imageWidth / imagesCount / 3) {
    const direction = deltaX > 0 ? -1 : 1;
    currentIndex = (currentIndex + direction + imagesCount) % imagesCount;
    startX = e.touches[0].clientX;

    const translateX = -currentIndex * (100 / imagesCount);
    if (translateX < oldTranslateX) {
      i++;
      if (i > 39)
        i = 0;
      mainImageBox.src = "./media/car-images/0_" + i + ".jpg";
    }
    else {
      i--;
      if (i < 0)
        i = 39;
      mainImageBox.src = "./media/car-images/0_" + i + ".jpg";
    }
    oldTranslateX = translateX;
  }
});

function ChangeGear(gear) {
  let gearSelector = document.getElementsByClassName("gear-selector")[0];
  switch (gear) {
    case "d":
      gearSelector.style = "top: 90px; height: 50px; width: 150px;";
      pauseCamera();
      break;
    case "p":
      gearSelector.style = "top: 230px; height: 50px; width: 150px;";
      pauseCamera();
      break;
    case "r":
      gearSelector.style = "top: 370px; height: 50px; width: 150px;";
      //Show camera
      playCamera();
      break;
  }
}

// Camera Section
feather.replace();
const cameraBox = document.querySelector('.display-cover');
const controls = document.querySelector('.controls');
const cameraOptions = document.querySelector('.video-options>select');
const video = document.querySelector('video');
let camera;
let streamStarted = false;

const constraints = {
  video: {
    width: {
      min: 1280,
      ideal: 1920,
      max: 2560,
    },
    height: {
      min: 720,
      ideal: 1080,
      max: 1440
    },
  }
};

// find all camera devices function
const getCameraSelection = async () => {
  const devices = await navigator.mediaDevices.enumerateDevices();
  const videoDevices = devices.filter(device => device.kind === 'videoinput');
  const options = videoDevices.map(videoDevice => {
    return `<option value="${videoDevice.deviceId}">${videoDevice.label}</option>`;
  });
  cameraOptions.innerHTML = options.join('');
};

// event for start recording function
function playCamera() {
  cameraBox.classList.remove('d-none');
  if (streamStarted) {
    video.play();
    return;
  }
  if ('mediaDevices' in navigator && navigator.mediaDevices.getUserMedia) {
    const updatedConstraints = {
      ...constraints,
      deviceId: {
        exact: cameraOptions.value
      }
    };
    startStream(updatedConstraints);
  }
  else {
    alert("Your device don't have camera !!!");
  }
};

// start recording function
const startStream = async (constraints) => {
  const stream = await navigator.mediaDevices.getUserMedia(constraints);
  camera = stream;
  handleStream(stream);
};

// config some things for start recording function
const handleStream = (stream) => {
  video.srcObject = stream;
  streamStarted = true;
};

// call find all camera devices function
getCameraSelection();

// event for switch between camera devices
cameraOptions.onchange = () => {
  const updatedConstraints = {
    ...constraints,
    deviceId: {
      exact: cameraOptions.value
    }
  };
  startStream(updatedConstraints);
};

// stop recording
function pauseCamera() {
  if(camera != undefined){
    camera.getTracks()[0].stop();
    video.src = '';
    streamStarted = false;
    cameraBox.classList.add('d-none');
  }
};
// End Camera Section

// Show Warnings
function ShowWarning() {
  document.getElementsByTagName("main")[0].style = "box-shadow: 0 0 50px 10px red inset;";
  document.getElementById("warningBox").classList.add("warningBox");
}

//ShowWarning();
// End Show Warnings

// End Car-Simulator